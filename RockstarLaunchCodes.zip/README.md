
# Rockstar Barnum & Co – Deployment README

## Overview
This project powers the AI-integrated operations dashboard including Gmail, partner mapping, GitHub CI/CD sync, and visual intelligence.

## Manual Commands
- Trigger Gmail ingest: POST /api/ingest-gmail
- Refresh deployment logs: POST /api/github/pull
- Contact sponsor zones: GET /api/contact-sponsors

## Environment Variables
All env vars must be set in Vercel/Firebase.

## Admin
To add collaborators or rotate tokens, use Firebase IAM and Vercel dashboard.
