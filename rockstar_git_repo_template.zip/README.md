
# Rockstar Barnum & Co – Admin Dashboard

This repository hosts the frontend React admin dashboard and backend functions for syncing Gmail, Drive, GitHub, partners, and AI operations for Preservation STARZ, Phoenecia Online, BarnumsStudio, and Rockstar Barnum Co.

## Folders

- /public – Static assets (favicon, manifest)
- /src – React app with views for Inbox, Sponsors, Map, etc.
- /api – Serverless functions (Gmail sync, GitHub webhook, Meta AI)
- /firebase – Firebase config and functions (Firestore, auth, deploy)
- /.github – Actions and workflows

## Deployment

Deployed to Vercel (frontend) and Firebase (backend functions).

## License

MIT © Rockstar Barnum & Co
